-- Run in Supabase → SQL Editor. Recreates kv_admin_entities and seeds the Super Admin.
-- Login: User ID "Anmol" OR "anmol@libmatrix.com" (case-insensitive) / Password: Anmol@2003

CREATE TABLE IF NOT EXISTS kv_admin_entities (
    "key"      VARCHAR(100) PRIMARY KEY,
    value      TEXT,                                  -- JSON text; the server also accepts a single object or jsonb
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO kv_admin_entities ("key", value) VALUES
('admins', '[{"id":"ADM1700000000000","username":"Anmol","name":"Anmol Kumar","email":"anmol@libmatrix.com","role":"Super Admin","status":"active","password":"$2a$10$aSP/f5Fe09mgIRA6HdOWs.tq5yI530FiCu07bd9ucdACBHRKe92ZW","lastLogin":null}]')
ON CONFLICT ("key") DO UPDATE SET value = EXCLUDED.value, updated_at = CURRENT_TIMESTAMP;

-- The other KV rows the app expects start empty (the server also creates them on demand):
INSERT INTO kv_admin_entities ("key", value) VALUES ('staff','[]'), ('agents','[]'), ('students','[]')
ON CONFLICT ("key") DO NOTHING;

-- Supabase exposes public tables through its REST API; this table holds credentials, so lock it down.
-- (The Node server connects with the DB URL as the owner role and is unaffected.)
ALTER TABLE kv_admin_entities ENABLE ROW LEVEL SECURITY;

-- Check:
SELECT "key", left(value, 120) AS value_preview FROM kv_admin_entities;
