-- ════════════════════════════════════════════════════════════════════
-- Anmol LibMatrix — Super Admin seed / verify  (Supabase SQL Editor)
-- Login after running:   Username: Anmol     Password: Anmol@2003
-- ➜ Change the password inside the Admin panel right after your first login.
-- The password is stored as a bcrypt hash (generated inside Postgres by pgcrypto) — never plain text.
-- ════════════════════════════════════════════════════════════════════

-- STEP 0 — make sure the table exists (the server also creates it on first start; harmless if it already exists)
create table if not exists kv_admin_entities (
  "key"      varchar(100) primary key,
  value      text,
  updated_at timestamp default current_timestamp
);

-- STEP 1 — INSERT or RESET the "Anmol" super admin. Other admins already in the table are KEPT.
with new_admin as (
  select jsonb_build_object(
    'id',        'adm1',
    'name',      'Anmol Kumar',
    'username',  'Anmol',
    'password',  extensions.crypt('Anmol@2003', extensions.gen_salt('bf', 10)),
    'role',      'superadmin',
    'lastLogin', null
  ) as a
)
insert into kv_admin_entities ("key", value, updated_at)
select 'admins', jsonb_build_array(a)::text, now() from new_admin
on conflict ("key") do update
set value = (
      coalesce(
        (select jsonb_agg(e)
           from jsonb_array_elements(coalesce(nullif(kv_admin_entities.value, '')::jsonb, '[]'::jsonb)) e
          where lower(e->>'username') <> 'anmol'),
        '[]'::jsonb)
      || (select jsonb_build_array(a) from new_admin)
    )::text,
    updated_at = now();

-- STEP 2 — VERIFY. Expect one row: username = Anmol, role = superadmin, hash_prefix = $2a$10$,
--          default_password_matches = true
select a->>'username'                                         as username,
       a->>'role'                                             as role,
       left(a->>'password', 7)                                as hash_prefix,
       (extensions.crypt('Anmol@2003', a->>'password') = a->>'password') as default_password_matches
  from kv_admin_entities,
       jsonb_array_elements(value::jsonb) a
 where "key" = 'admins'
   and lower(a->>'username') = 'anmol'
   and a->>'password' like '$2%';      -- only bcrypt rows are checked (other admins are never touched)

-- Quick look at ALL admins (hash_prefix of a legacy plain-text password will not start with $2):
-- select a->>'username' as username, a->>'role' as role, left(a->>'password', 4) as pw_prefix
--   from kv_admin_entities, jsonb_array_elements(value::jsonb) a where "key" = 'admins';

-- ── Optional: nuke every admin and start with ONLY "Anmol" ──
-- delete from kv_admin_entities where "key" = 'admins';   -- then re-run STEP 1
