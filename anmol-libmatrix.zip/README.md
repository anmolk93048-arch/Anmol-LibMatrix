# Anmol LibMatrix

```
anmol-libmatrix/
├─ netlify.toml            Netlify: publish = frontend
├─ render.yaml             Render blueprint (rootDir = backend)
├─ frontend/               → Netlify
│  ├─ index.html           landing page ( / )
│  ├─ Admin_Login.html  Agent_Login.html  PFMS_login.html
│  ├─ HRMS_login.html   Student_Attendance.html  INVOICE_LOGIN.html
│  ├─ config.js            API_BASE (Render URL) – edit here only
│  ├─ portal-shell.js/.css shared logout, role modal, footer, attendance sync
│  └─ anmol_libmatrix_logo.png   (PLACEHOLDER – replace with your real logo)
└─ backend/                → Render
   ├─ server.js            your original server + 5 small patches
   ├─ supabase-portals.js  supabase-js layer
   ├─ supabase_schema.sql  run once in Supabase SQL Editor
   ├─ package.json  .env.example
```

## 1. Supabase
SQL Editor → paste `backend/supabase_schema.sql` → Run.
Project Settings → API → copy **Project URL** and the **service_role** key.

## 2. GitHub
```bash
cd anmol-libmatrix
git init && git add . && git commit -m "Anmol LibMatrix: frontend + backend + Supabase"
git branch -M main
git remote add origin https://github.com/<you>/<repo>.git
git push -u origin main
```
Replace `frontend/anmol_libmatrix_logo.png` with your real logo first. `.env` is git-ignored.

## 3. Render (backend)
New → Web Service → connect repo → **Root Directory `backend`**, Build `npm install`, Start `npm start`.
Environment: `SUPABASE_URL`, `SUPABASE_KEY` (service_role), `DATABASE_URL`, `JWT_SECRET`,
`PII_ENCRYPTION_KEY`, `FRONTEND_URL` (your Netlify URL). See `backend/.env.example`.
Check `https://<render-url>/api/health` and `/api/portal/health`.

## 4. Netlify (frontend)
Add new site → Import from GitHub → build command empty, publish dir `frontend` (netlify.toml sets it).
If your Render URL differs from `library-backend-4efk.onrender.com`, edit `frontend/config.js`.
