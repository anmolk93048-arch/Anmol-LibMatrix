/* Anmol LibMatrix — one place to point every portal at the backend.
   Change API_BASE only if your Render URL changes. */
window.ANMOL_CONFIG = {
  API_BASE: 'https://library-backend-4efk.onrender.com/api',
  HOME: 'index.html'
};
window.SHDL_API_BASE = window.SHDL_API_BASE || window.ANMOL_CONFIG.API_BASE; // used by every portal page
window.SHDL_HOME_URL = window.SHDL_HOME_URL || window.ANMOL_CONFIG.HOME;     // logout target
