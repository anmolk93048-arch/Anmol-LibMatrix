-- Anmol LibMatrix — Supabase tables used by backend/supabase-portals.js
-- Run once: Supabase Dashboard -> SQL Editor -> New query -> paste -> Run.
-- (Your existing tables — users, attendance_records, kv_* etc. — are untouched.)

create table if not exists portal_login_attempts (
  id bigserial primary key,
  portal text not null, role text, username text,
  success boolean not null, reason text, ip text, user_agent text,
  created_at timestamptz not null default now()
);
create index if not exists idx_pla_portal_time on portal_login_attempts (portal, created_at desc);

create table if not exists portal_sessions (
  id bigserial primary key,
  event text not null check (event in ('role_selected','logout')),
  role text, location text, username text, ip text,
  created_at timestamptz not null default now()
);

create table if not exists revoked_tokens (
  token_hash text primary key,
  role text, username text,
  expires_at timestamptz not null,
  created_at timestamptz not null default now()
);
create index if not exists idx_revoked_exp on revoked_tokens (expires_at);

create table if not exists portal_registrations (
  id bigserial primary key,
  portal text not null, full_name text, mobile text, email text,
  status text not null default 'pending',
  payload jsonb not null default '{}'::jsonb, ip text,
  created_at timestamptz not null default now()
);
create index if not exists idx_preg_portal on portal_registrations (portal, created_at desc);

create table if not exists portal_submissions (
  id bigserial primary key,
  portal text not null, kind text not null, route text,
  actor text, actor_role text,
  payload jsonb not null default '{}'::jsonb, ip text,
  created_at timestamptz not null default now()
);
create index if not exists idx_psub_portal_kind on portal_submissions (portal, kind, created_at desc);

create table if not exists portal_attendance (
  id bigserial primary key,
  student_id text, student_name text not null,
  att_date date not null, batch text not null default '',
  status text not null check (status in ('Present','Absent','Late')),
  marked_by text, source text default 'student_portal',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (student_name, att_date, batch)
);
create index if not exists idx_patt_date on portal_attendance (att_date desc);

-- Lock everything down: RLS ON with NO policies = the public/anon key can read or write nothing.
-- Only the backend (service_role key in SUPABASE_KEY) can access these tables.
alter table portal_login_attempts enable row level security;
alter table portal_sessions       enable row level security;
alter table revoked_tokens        enable row level security;
alter table portal_registrations  enable row level security;
alter table portal_submissions    enable row level security;
alter table portal_attendance     enable row level security;
