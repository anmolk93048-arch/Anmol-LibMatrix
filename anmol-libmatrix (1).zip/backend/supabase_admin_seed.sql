-- Anmol LibMatrix — create / reset the Super Admin login directly in Supabase.
-- Supabase Dashboard -> SQL Editor -> paste -> Run.
-- Login afterwards:   Username: Anmol     Password: Anmol@2003      <-- CHANGE IT right after first login
-- (the value below is the bcrypt hash of that password; the server only ever stores/compares hashes)

-- A) FIRST-TIME SETUP or FULL RESET  (replaces the whole admins list with this one admin)
insert into kv_admin_entities ("key", value)
values ('admins', '[{"id":"adm1","name":"Anmol Kumar","username":"Anmol","password":"$2a$10$Yexdyy44OeeAgiwJIuC3vusHK7nw0mzmTtQsCEooph8fkMPAI8jTi","role":"superadmin","lastLogin":null}]')
on conflict ("key") do update set value = excluded.value, updated_at = now();

-- B) CHECK what is stored (password column shows a hash starting with $2a$10$ or $2b$10$)
-- select "key", left(value, 160) as preview, updated_at from kv_admin_entities where "key" = 'admins';

-- C) Reset ONE admin's password but keep the other admins (replace NEW_HASH with a hash from:
--    node backend/scripts/reset-admin.js <username> <new-password> --print-only )
-- update kv_admin_entities
--    set value = (select jsonb_agg(case when e->>'username' = 'Anmol'
--                                       then jsonb_set(e, '{password}', to_jsonb('NEW_HASH'::text)) else e end)::text
--                 from jsonb_array_elements(value::jsonb) e),
--        updated_at = now()
--  where "key" = 'admins';
