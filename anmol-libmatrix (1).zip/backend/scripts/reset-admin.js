#!/usr/bin/env node
/* Create or reset an admin directly in the database (merges with existing admins).
   Usage:  node scripts/reset-admin.js <username> <new-password> [--name "Full Name"] [--print-only]
   Needs DATABASE_URL (same as the server; reads backend/.env). */
require('dotenv').config();
const bcrypt = require('bcryptjs');
const args = process.argv.slice(2);
const printOnly = args.includes('--print-only');
const nameIdx = args.indexOf('--name');
const name = nameIdx > -1 ? args[nameIdx + 1] : null;
const [username, password] = args.filter(a => !a.startsWith('--') && a !== name);
if (!username || !password) { console.error('Usage: node scripts/reset-admin.js <username> <new-password> [--name "Full Name"] [--print-only]'); process.exit(1); }
if (password.length < 8) { console.error('Password must be at least 8 characters.'); process.exit(1); }
const hash = bcrypt.hashSync(password, 10);
if (printOnly) { console.log(hash); process.exit(0); }
if (!process.env.DATABASE_URL) { console.error('DATABASE_URL is not set.'); process.exit(1); }
const { Pool } = require('pg');
const db = new Pool({ connectionString: process.env.DATABASE_URL, ssl: { rejectUnauthorized: false } });
(async () => {
  const { rows } = await db.query(`select value from kv_admin_entities where "key" = 'admins'`);
  let list = []; try { list = JSON.parse(rows[0] && rows[0].value) || []; } catch (e) {}
  const i = list.findIndex(a => a && String(a.username).toLowerCase() === username.toLowerCase());
  if (i >= 0) list[i] = { ...list[i], password: hash };
  else list.push({ id: 'adm_' + Date.now(), name: name || username, username, password: hash, role: 'superadmin', lastLogin: null });
  await db.query(`insert into kv_admin_entities ("key", value) values ('admins', $1) on conflict ("key") do update set value = excluded.value, updated_at = now()`, [JSON.stringify(list)]);
  console.log((i >= 0 ? 'Password reset for ' : 'Admin created: ') + username + '  (total admins: ' + list.length + ')');
  await db.end();
})().catch(e => { console.error('Failed:', e.message); process.exit(1); });
